package shapes;

import com.example.paintdemo.Circle;
import javafx.scene.paint.Color;

public class Shapes {

    public static Shape circleOf(double radius, double x, double y, Color color) {
        return new Circle(radius, x, y, color);
    }

    public static Shape squareOf(double x, double y, double size, Color color) {
        return new Square(color, x, y, size);
    }
}

