package com.example.paintdemo;

import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import shapes.Shapes;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.io.File;


public class PaintController {

    Model model;

    @FXML
    private Canvas canvas;

    @FXML
    private ColorPicker colorPicker;

    @FXML
    private Button squareButton;

    @FXML
    private Button circleButton;

    @FXML
    private Spinner<Integer> shapeSize;

    public PaintController() {
    }

    public PaintController(Model model) {
        this.model = model;
    }


    @FXML
    public void squareButtonClicked(ActionEvent event) {


    }

    @FXML
    public void circleButtonClicked(MouseEvent event) {
        test();


    }

    public void initialize() {

        model = new Model();

        canvas.widthProperty().addListener(observable -> draw());
        canvas.heightProperty().addListener(observable -> draw());
        colorPicker.valueProperty().bindBidirectional(model.colorProperty());

       // if(squareButtonClicked().isSelected()){

        }

        //bind storlek till spinner för shapeSize?



    private void draw() {

        var gc = canvas.getGraphicsContext2D();
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        for (var shape : model.shapes) {
            shape.draw(gc);

        }
    }

    public void onSave() {
        try {
            Image snapshot = canvas.snapshot(null, null);

            ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", new File("Artwork.png"));
        } catch (Exception e) {
            System.out.println("Failed to save image" + e);
        }
    }

    public void onExit() {
        Platform.exit();
    }

    public void test(){

        System.out.println("test");
    }

    public void canvasClicked(MouseEvent event) {
        if (event.getButton().name().equals("PRIMARY"))
            model.shapes.add(Shapes.circleOf(10.0, event.getX(), event.getY(),  model.getColor()));
            //model.shapes.add(Shapes.rectangleOf(event.getX(), event.getY(), 10.0, model.getColor()));
        else if (event.getButton().name().equals("SECONDARY")) {
            model.shapes.stream()
                    .filter(shape -> shape.isInside(event.getX(), event.getY()))
                    .findFirst().ifPresent(shape -> shape.setColor(Color.RED));
        }

        draw();
    }

}